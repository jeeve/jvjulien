/* Automatically generated file (don't edit) */
/*=====================================================================*/
/*    serrano/prgm/project/hop/2.0.x/etc/hop-autoconf.js.in            */
/*    -------------------------------------------------------------    */
/*    Author      :  Manuel Serrano                                    */
/*    Creation    :  Thu May 18 05:26:40 2006                          */
/*    Last change :  Wed Feb 10 08:22:28 2010 (serrano)                */
/*    Copyright   :  2006-10 Manuel Serrano                            */
/*    -------------------------------------------------------------    */
/*    All non portable components of the HOP runtime system. All other */
/*    HOP script libraries are supposed *not* to check features        */
/*    availabilities.                                                  */
/*=====================================================================*/

/*---------------------------------------------------------------------*/
/*    undefined value                                                  */
/*---------------------------------------------------------------------*/
var undefined;

/*---------------------------------------------------------------------*/
/*    Name and version                                                 */
/*---------------------------------------------------------------------*/
/*** META ((export hop-name) (arity #t)) */
function hop_name() {
   return "Hop";
}

/*** META ((export hop-version) (arity #t)) */
function hop_version() {
   return "2.0.1";
}

/*** META ((export hop-backend) (arity #t)) */
function hop_backend() {
   return "native";
}

/*** META ((export hop-url) (arity #t)) */
function hop_url() {
   return "http://hop.inria.fr/";
}

/*---------------------------------------------------------------------*/
/*    Hop configuration                                                */
/*---------------------------------------------------------------------*/
var hop_enable_location_event = true;

/*---------------------------------------------------------------------*/
/*    hop-service-base                                                 */
/*    -------------------------------------------------------------    */
/*    The prefix of all HOP weblets.                                   */
/*---------------------------------------------------------------------*/
/*** META ((export hop-service-base) (arity #t)) */
function hop_service_base() {
   return "/hop";
}

/*---------------------------------------------------------------------*/
/*    hop_get_flash_version ...                                        */
/*---------------------------------------------------------------------*/
function hop_get_flash_version() {
   if( navigator.mimeTypes
       && navigator.mimeTypes[ "application/x-shockwave-flash" ] ) {
      var p = navigator.mimeTypes[ "application/x-shockwave-flash" ].enabledPlugin;
   
      if( p && p.description ) {
	 var d = p.description;

	 if( (typeof d == "string") && (d.indexOf( "Shockwave Flash " ) == 0) ) {
	    return parseFloat( d.substring( 16, d.indexOf( " ", 16 ) ) );
	 }
      }
   }

   return 0;
}

/*---------------------------------------------------------------------*/
/*    hop_Config ...                                                   */
/*    -------------------------------------------------------------    */
/*    This mostly contains external information that cannot be         */
/*    deduced by introspection.                                        */
/*---------------------------------------------------------------------*/
function hop_Config() {
  /* cpu speed */
  this.cpu_speed = 100;
  if( navigator.platform.indexOf( "armv6" ) >= 0 ) this.cpu_speed = 40;
  if( navigator.platform.indexOf( "armv5" ) >= 0 ) this.cpu_speed = 30;
  if( navigator.platform.indexOf( "WinCE" ) >= 0 ) this.cpu_speed = 30;
  
  /* gpu speed */
  this.gpu_speed = 100;
  if( navigator.platform.indexOf( "armv6" ) >= 0 ) this.gpu_speed = 30;

  /* js speed */
  this.js_speed = 50;

  /* pointing device */
  this.is_tablet = ( navigator.userAgent.indexOf( "Tablet" ) >= 0 );

  /* flash version */
  this.flash_version = hop_get_flash_version();

  /* html5 */
  var audio = document.createElement( "audio" );
  this.html5_video = "play" in document.createElement( "video" );
  this.html5_audio = "play" in audio && audio.constructor === HTMLAudioElement;

  /* Geolocation */
  this.geolocation = (navigator.geolocation ? true : false);

  /* default navigator setting */
  this.mouse_left_button = 0;
  this.flash_external_interface = false;
  this.flash_audio = false;
  this.flash_markup = "embed";
  this.inline_image = false;
  this.filtered_errors = [];
  this.css = 2.1;
  this.xhr_multipart = false; // see hop_make_xml_http_request conf
  this.clone_innerHTML = false; // see hop_create_element (hop-dom.js)
  this.eval_innerHTML = true;

  /* navigator specific configuration */
  if( navigator.userAgent.indexOf( "MSIE" ) >= 0 ) {
     this.js_speed = 20;
     this.navigator_family = "msie";
     this.mouse_left_button = 1;
     this.flash_external_interface = true;
     this.flash_audio = false;
     this.flash_markup = "object";
     this.inline_image = false;
     if( navigator.userAgent.indexOf( "MSIE 6.0" ) >= 0 ) {
	hop_enable_location_event = false;
     }
  } else if( navigator.userAgent.indexOf( "Opera" ) >= 0 ) {
     this.js_speed = 70;
     this.navigator_family = "opera";
     this.mouse_left_button = 0;
     this.flash_external_interface = false;
     this.flash_audio = false;
     this.flash_markup = "embed";
     this.inline_image = true;
     this.clone_innerHTML = true;
  } else if( navigator.userAgent.indexOf( "Chrome" ) >= 0 ) {
     this.js_speed = 100;
     this.navigator_family = "chrome";
     this.mouse_left_button = 0;
     this.flash_external_interface = true;
     this.flash_audio = false;
     this.flash_markup = "embed";
     this.inline_image = true;
     this.css = 3;
     this.clone_innerHTML = true;
     if( ! "Window" in window || window.Window === undefined ) {
       window.Window = window.constructor;
     }
  } else if( navigator.userAgent.indexOf( "Safari" ) >= 0 ) {
     this.js_speed = 80;
     this.navigator_family = "safari";
     this.mouse_left_button = 0;
     this.flash_external_interface = true;
     this.flash_audio = false;
     this.flash_markup = "embed";
     this.inline_image = true;
     this.clone_innerHTML = true;
  } else if( navigator.userAgent.indexOf( "WebKit" ) >= 0 ) {
     this.navigator_family = "webkit";
     this.js_speed = 80;
     this.mouse_left_button = 0;
     this.flash_external_interface = true;
     this.flash_audio = false;
     this.flash_markup = "embed";
     this.inline_image = true;
     this.clone_innerHTML = true;
  } else if( navigator.userAgent.indexOf( "KHTML" ) >= 0 ) {
     this.navigator_family = "khtml";
     this.mouse_left_button = 1;
     this.flash_external_interface = true;
     this.flash_audio = false;
     this.flash_markup = "embed";
     this.inline_image = true;
     this.clone_innerHTML = true;
  } else if( navigator.userAgent.indexOf( "Mozilla" ) >= 0 ) {
     if( navigator.userAgent.match( /3.[56][^ ]*$/ ) ) {
        /* Firefox 3.5, 3.6 */
        this.js_speed = 75;	    
        this.css = 3;
     } else if( navigator.userAgent.match( /3.0[^ ]*$/ ) ) {
        /* Firefox 3.0, 3.1 */
        this.js_speed = 60;	    
     } else {
        this.js_speed = 50;
     }

     this.navigator_family = "mozilla";
     this.mouse_left_button = 0;
     this.flash_external_interface = true;
     this.flash_audio = true;
     this.flash_markup = "embed";
     this.inline_image = true;
     this.filtered_errors = ["javascript:top.location+\"__flashplugin_unique__\"", "tipElement.ownerDocument is null"];
  } else {
     alert( "Unknown navigator (" + navigator.userAgent +
	    "), using default settings..." );
  }

  /* Screen Dimensions */
  this.screen_width = screen.width;
  this.screen_height = screen.height;
  this.screen_available_width = screen.availWidth;
  this.screen_available_height = screen.availHeight;
  this.screen_color_depth = screen.colorDepth;
  
     
  this.version = hop_version();
  this.backend = hop_backend();
}

/*---------------------------------------------------------------------*/
/*    hop_config ...                                                   */
/*---------------------------------------------------------------------*/
var hop_config = new hop_Config();

/*---------------------------------------------------------------------*/
/*    hop_config_get ...                                               */
/*---------------------------------------------------------------------*/
/*** META ((export hop-config) (arity #f)) */
function hop_config_get( key ) {
   if( arguments.length == 0 ) {
      var l = null;
      
      for( var p in hop_config ) {
	 var c = new sc_Pair( sc_jsstring2symbol( p ), hop_config[ p ]);
	 l = new sc_Pair( c, l );
      }
      
      return l;
   } else if( !sc_isSymbol( key ) ) {
      return false;
   } else {
      return hop_config[ sc_symbol2jsstring( key ) ];
   }
}

/*---------------------------------------------------------------------*/
/*    hop_flash_minversion_set ...                                     */
/*---------------------------------------------------------------------*/
function hop_flash_minversion_set( v ) {
   if( v > hop_config.flash_version ) hop_config.flash_version = v;
}

/*---------------------------------------------------------------------*/
/*    hop_flash_audio_set ...                                          */
/*---------------------------------------------------------------------*/
function hop_flash_audio_set( v ) {
   hop_config.flash_audio = v;
}

/*---------------------------------------------------------------------*/
/*    hop_innerHTML_need_evalp ...                                     */
/*    -------------------------------------------------------------    */
/*    This test sets the variable hop_innerHTML_need_eval to           */
/*    false if innerHTML evaluates the scripts contained in the        */
/*    DOM nodes it receives as argument.                               */
/*---------------------------------------------------------------------*/
var hop_innerHTML_need_evalp = true;

var tmp = document.createElement( "div" );

try {
   tmp.innerHTML = "<script type='text/javascript'>hop_config.eval_innerHTML = false;</script>";
   tmp = tmp.cloneNode( true );
   if( ("body" in document) && (document.body != null) ) {
      document.body.appendChild( tmp );
      document.body.removeChild( tmp );
   } else {
      if( ("documentElement" in document) &&  
          (document.documentElement != null) ) {
	 document.documentElement.appendChild( tmp );
	 document.documentElement.removeChild( tmp );
      } else {
	 var body = document.getElementsByTagName( "body" )[ 0 ];
	 body.appendChild( tmp );
	 body.removeChild( tmp );
      }
   }
} catch( e ) {
     ;
}

/*---------------------------------------------------------------------*/
/*    hop_properties_to_string ...                                     */
/*---------------------------------------------------------------------*/
function hop_properties_to_string( obj ) {
   var res = "";
   var i = 0;
   for( var p in obj ) {
      if( i === 10 ) {
	 res += p + "\n";
	 i = 0;
      } else {
	 i++;
	 res += p + " ";
      }
   }
   return res;
}

/*---------------------------------------------------------------------*/
/*    hop_properties_values_to_string ...                              */
/*---------------------------------------------------------------------*/
function hop_properties_values_to_string( obj ) {
   var res = "";
   var i = 0;
   for( var p in obj ) {
      if( i === 10 ) {
	 res += p + "=" + obj[ p ] + "\n";
	 i = 0;
      } else {
	 i++;
	 res += p + "=" + obj[ p ] + " ";
      }
   }
   return res;
}

/*---------------------------------------------------------------------*/
/*    hop_is_html_element ...                                          */
/*---------------------------------------------------------------------*/
/*** META ((export html-element?) (arity 1)) */
var hop_is_html_element;

if( !("HTMLElement" in window) ) {
   hop_is_html_element = function hop_is_html_element( obj ) {
      return (obj != null)
              && (((obj instanceof Object) || (typeof obj == "object"))
	      && (typeof obj.innerHTML == "string"));
   } 
} else {
   var ifr = document.createElement( "iframe" );

   if( ifr instanceof HTMLElement ) {
      hop_is_html_element = function hop_is_html_element( obj ) {
	 return (obj != null) && (obj instanceof HTMLElement);
      }
   } else {
      /* this is konqueror */
      var ifproto = ifr.__proto__;
      hop_is_html_element = function hop_is_html_element( obj ) {
	 return (obj instanceof HTMLElement) || (obj.__proto__ == ifproto);
      }
   }
}

/*---------------------------------------------------------------------*/
/*    DOMFormElement ...                                               */
/*---------------------------------------------------------------------*/
var hop_is_dom_form_element;

try {
   if( undefined instanceof HTMLFormElement ) {
      /* this test is always false but it checks if HTMLFormElement */
      /* is a plain JavaScript class. See below the catch clause.   */
      hop_is_dom_form_element = function hop_is_dom_form_element( obj ) {
	 return false;
      };
   } else {
      hop_is_dom_form_element = function hop_is_dom_form_element( obj ) {
	 return obj instanceof HTMLFormElement;
      };
   }
} catch( e ) {
   /* on some browsers (guess how, always the same), HTMLFormElement is */
   /* an opaque object that is not implemented as a plain JavaScript    */
   /* class (i.e., a JavaScript function), hence instanceof cannot be   */
   /* used.                                                             */
   hop_is_dom_form_element = function hop_is_dom_form_element( obj ) {
      return hop_is_html_element( obj ) && (obj.tagName === "form");
   };
}
  
if( !("HTMLCollection" in window) ) {
   window.HTMLCollection = function() { return false; };
}

if( !("HTMLInputElement" in window) ) {
   window.HTMLInputElement = function() { return false; };
}

if( !("HTMLTextAreaElement" in window) ) {
   window.HTMLTextAreaElement = function() { return false; };
}

if( !("HTMLSelectElement" in window) ) {
   window.HTMLSelectElement = function() { return false; };
}

/*---------------------------------------------------------------------*/
/*    hop_make_xml_http_request ...                                    */
/*---------------------------------------------------------------------*/
var hop_make_xml_http_request;

if( "XMLHttpRequest" in window ) {
   var req = new XMLHttpRequest();
   
   hop_make_xml_http_request = function hop_make_xml_http_request() {
      return new XMLHttpRequest();
   }
   if( "multipart" in req ) {
      hop_config.xhr_multipart = true;
   }
} else {
   if( "ActiveXObject" in window ) {
      hop_make_xml_http_request = function hop_make_xml_http_request() {
	 try {
	    return new ActiveXObject( "Msxml2.XMLHTTP" );
	 } catch( e ) {
	    try {
	       return new ActiveXObject( "Microsoft.XMLHTTP" );
	    } catch( e ) {
	       alert( "*** ERROR: Don't know how to create XMLHttpRequest" );
	    }
	 }
      }
   } else {
      if( "XMLHttpRequest" in window ) {
	 hop_make_xml_http_request = function hop_make_xml_http_request() {
	    return new XMLHttpRequest();
	 }
      } else {
	 hop_make_xml_http_request = function hop_make_xml_http_request() {
	    alert( "*** ERROR: Don't know how to create XMLHttpRequest" );
	 }
      }
   }
}

/*---------------------------------------------------------------------*/
/*    hop_header_content_type ...                                      */
/*---------------------------------------------------------------------*/
var hop_header_content_type;
var hop_header_autoconf = hop_make_xml_http_request();

if( typeof hop_header_autoconf.getResponseHeader == "function" ) {
   hop_header_content_type = function hop_header_content_type( http ) {
      var h = http.getResponseHeader( "Content-Type" );

      if( h ) {
	 var i = h.indexOf( ";" );

	 if( i >= 0 ) {
	    return h.substring( 0, i );
	 } else {
	    return h;
	 }
      } else {
	 return "application/text";
      }
   }
} else {
   hop_header_content_type = function hop_header_content_type( http ) {
      var hds = http.getAllResponseHeaders();
      var i = hds.indexOf( "Content-Type" );

      if( i < 0 ) i = hds.indexOf( "content-type" );
      if( i < 0 ) i = hds.indexOf( "Content-type" );
      if( i < 0 ) return "application/text";

      var j = hds.indexOf( "\n", i + 1 );
      var s = (j >= 0) ? hds.substring( i, j ) : hds.substring( i, s.length );
      var m = s.match( "[ \t:]+([^ \n;]*)" );

      if( m )
	 return m[ 1 ];
      else
	 return "application/text";
   }
}

/*---------------------------------------------------------------------*/
/*    node_style_set ...                                               */
/*---------------------------------------------------------------------*/
function node_style_set_native( el, prop, value ) {
   var obj = el;
   
   if( (el instanceof String) || (typeof el === "string") )
      obj = document.getElementById( el );

   for( var i = 1; i < arguments.length; i += 2 ) {
      var p = arguments[ i ];
      var v = arguments[ i + 1 ];

      if( sc_isKeyword( p ) )
	 p = sc_keyword2jsstring( p );
   
      if( !(v instanceof String) && (typeof v !== "string") ) {
	 if( !v && (v != 0) ) {
	    sc_error( "node-style-set!", "Illegal \"" + p + "\" value: " + v, el );
	 } else {
	    v = v.toString();
	 }
      }

      if( !obj || !obj.style ) {
	 sc_error( "node-style-set!",
		   "Illegal object while setting \"" + p + ": " + v + "\"",
		   el );
      }

      try {
	 if( p in obj.style ) {
	    obj.style[ p ] =  v;
	 } else {
	    obj.style.setProperty( p, v, "" );
	 }
      } catch( e ) {
	 sc_error( "node-style-set!", "Can't set property \"" + p + "\"", el );
      }
   }
}

function node_style_set_array( el, prop, value ) {
   var obj = el;
   
   if( (el instanceof String) || (typeof el === "string") )
      obj = document.getElementById( el );

   for( var i = 1; i < arguments.length; i += 2 ) {
      var p = arguments[ i ];
      var v = arguments[ i + 1 ];
      
      if( sc_isKeyword( p ) )
	 p = sc_keyword2jsstring( p );
   
      if( !(v instanceof String) && (typeof v !== "string") ) {
	 if( !v && (v != 0) ) {
	    sc_error( "node-style-set!", "Illegal \"" + p + "\" value: "+ v, el );
	 } else {
	    v = v.toString();
	 }
      }
   
      obj.style[ p ] = v;
   }
}

/*** META ((export node-style-set!) (arity -3)) */
var node_style_set = function( el, prop, value ) {
   var obj = el;
   
   if( (el instanceof String) || (typeof el === "string") )
      obj = document.getElementById( el );

   try {
      if( "setProperty" in obj.style ) {
         node_style_set = node_style_set_native;
      	 return node_style_set_native.apply( null, arguments );
      } else {
	 node_style_set = node_style_set_array;
	 return node_style_set_array.apply( null, arguments );
      }
   } catch( e ) {
      sc_error( "node-style-set!", "Can't set property \"" + prop + "\"", el );
  }
}

/*---------------------------------------------------------------------*/
/*    hop_active_location_timeout ...                                  */
/*    -------------------------------------------------------------    */
/*    The frequency, new locations are checked. On slow CPU (e.g.,     */
/*    ARM processors), use a reduced frequency.                        */
/*---------------------------------------------------------------------*/
var hop_active_location_timeout =
   ((hop_config.cpu_speed < 66) ? 100 : 250);

/*---------------------------------------------------------------------*/
/*    setInterval ...                                                  */
/*---------------------------------------------------------------------*/
var hop_has_setInterval = true;

try {
   var i = setInterval( function() { ; }, 1000 );
   clearInterval( i );
} catch( e ) {
   var hop_has_setInterval = false;
}

/*---------------------------------------------------------------------*/
/*    Event handlers                                                   */
/*---------------------------------------------------------------------*/
var hop_add_native_event_listener = undefined;
var hop_remove_native_event_listener = undefined;
/*** META ((export stop-event-propagation) (arity -2)) */
var hop_stop_propagation = undefined;
var hop_has_event20 = false;

try {
   hop_has_event20 = document.implementation.hasFeature( "Events" , "2.0" );
} catch( e ) {
   ;
}

if( hop_has_event20 ) {
   hop_add_native_event_listener = function( obj, event, proc, capture ) {
      if( "addEventListener" in obj ) {
         var f = hop_callback( proc );
         var i = "on" + event + "hdl";

         if( !(i in obj ) ) obj[ i ] = [];
         obj[ i ][ proc ] = f;

	 return obj.addEventListener( event, f, capture );
      } else {
	 throw new Error( "add-event-listener!: cannot add `" 
			  + event + "' listener for object: "
			  + obj );
      }
   }

   hop_remove_native_event_listener = function( obj, event, proc, capture ) {
      if( "removeEventListener" in obj ) {
	var i = "on" + event + "hdl";
        var h = obj[ i ];

        if( h !== undefined ) {
	   var p = obj[ i ][ proc ];

	   if( p !== undefined ) {
	      h[ p ] = undefined;
	      return obj.removeEventListener( event, p, capture );
	   }
	}
      } else {
	 throw new Error( "remove-event-listener!: cannot remove `"
			  + event + "' listener for object: "
			  + obj );
      }
   }

   hop_stop_propagation = function( event, def ) {
      if( !def ) event.preventDefault();
      event.stopPropagation();
      event.isStopped = true;
   }
} else {
   hop_add_native_event_listener = function( obj, event, proc, capture ) {
      var f = hop_callback( proc );
      var p = function(_) { return f( window.event ) };
      var i = "on" + event + "hdl";

      if( obj[ i ] === undefined ) obj[ i ] = [];
      obj[ i ][ proc ] = p;

      return obj.attachEvent( "on" + event, p );
   }

   hop_remove_native_event_listener = function( obj, event, proc, capture ) {
      var i = "on" + event + "hdl";
      var h = obj[ i ];

      if( h !== undefined ) {
	 var p = obj[ i ][ proc ];

	 if( p !== undefined ) {
	    h[ p ] = undefined;
	    return obj.detachEvent( "on" + event, p );
	 }
      }

      return false;
   }

   hop_stop_propagation = function( event, def ) {
      if( !def ) event.cancelBubble = true;
      event.returnValue = false;
      event.isStopped = true;
   }
}

/*---------------------------------------------------------------------*/
/*    hop_deinline_image ...                                           */
/*    -------------------------------------------------------------    */
/*    This function is invoked on inline images. It gives the          */
/*    browser a chance to load the inlined image. This is particularly */
/*    important for browsers such as IE that cannot handle inline      */
/*    images.                                                          */
/*---------------------------------------------------------------------*/
function hop_deinline_image( el, src ) {
   if( !el.deinlined ) {
      el.deinlined = true;
      el.src = src;
   }
}

/*---------------------------------------------------------------------*/
/*    mouse coords ...                                                 */
/*---------------------------------------------------------------------*/
/*** META ((export event-mouse-x) (arity 1)) */
var hop_event_mouse_x = undefined;
/*** META ((export event-mouse-y) (arity 1)) */
var hop_event_mouse_y = undefined;
/*** META ((export event-mouse-button) (arity 1)) */
var hop_event_mouse_button = undefined;
/*** META ((export event-key-code) (arity 1)) */
var hop_event_key_code = undefined;
/*** META ((export event-value)
           (arity #t)
           (peephole: (postfix ".value"))) */
function hop_event_value( evt ) { return evt.value; }
/*** META ((export event-response-text)
           (arity #t)
           (peephole: (postfix ".responseText"))) */
function hop_event_response_text( evt ) { return evt.responseText; }

if( hop_has_event20  ) {
   hop_event_mouse_x = function hop_event_mouse_x( event ) {
      return event.pageX;
   }
   hop_event_mouse_y = function hop_event_mouse_y( event ) {
      return event.pageY;
   }
   hop_event_key_code = function hop_event_key_code( event ) {
      return event.which;
   }
} else {
   hop_event_mouse_x = function hop_event_mouse_x( event ) {
      if( (document.body != null) &&
	  (document.documentElement.scrollLeft != null) ) {
	 return event.clientX + document.documentElement.scrollLeft;
      } else {
	 return event.clientX + document.body.scrollLeft;
      }
   }
   hop_event_mouse_y = function hop_event_mouse_y( event ) {
      if( (document.body != null) &&
	  (document.documentElement.scrollTop != null) ) {
	 return event.clientY + document.documentElement.scrollTop;
      } else {
	 return event.clientY + document.body.scrollTop;
      }
   }
   hop_event_key_code = function hop_event_key_code( event ) {
      return event.keyCode;
   }
}

switch( hop_config.mouse_left_button ) {
   case 0:
      hop_event_mouse_button = function hop_event_mouse_button( e ) {
	 return e.button + 1;
      };
      break;
   case 1:
      hop_event_mouse_button = function hop_event_mouse_button( e ) {
	 return e.button;
      }
      break;
   default:
      hop_event_mouse_button = function hop_event_mouse_button( e ) {
	 return e.button + (1 - hop_config.mouse_left_button);
      }
}

/*---------------------------------------------------------------------*/
/*    hop_window_width/height ...                                      */
/*---------------------------------------------------------------------*/
/*** META ((export main-window-width) (arity 0)) */
var hop_main_window_width = undefined;
/*** META ((export main-window-height) (arity 0)) */
var hop_main_window_height = undefined;
/*** META ((export main-window-orientation) (arity 0)) */
var hop_main_window_orientation = undefined;

if( isNaN( window.innerWidth ) ) {
   hop_main_window_width = function hop_main_window_width() {
      return document.documentElement.clientWidth;
   }
   hop_main_window_height = function hop_main_window_height() {
      return document.documentElement.clientHeight;
   }
} else {
   hop_main_window_width = function hop_main_window_width() {
      return window.innerWidth;
   }
   hop_main_window_height = function hop_main_window_height() {
      return window.innerHeight;
   }
}

var hop_orientation = false;
hop_main_window_orientation = function hop_main_window_orientation() {
  if( !hop_orientation ) {
     hop_orientation = sc_jsstring2symbol( "landscape" );
  }
  return hop_orientation;
}

/* backward compatibility */
/*** META ((export current-window-width) (arity 0)) */
var hop_current_window_width = hop_main_window_width;
/*** META ((export current-window-height) (arity 0)) */
var hop_current_window_height = hop_main_window_height;

/*---------------------------------------------------------------------*/
/*    hop_screen_dimensions ...                                        */
/*---------------------------------------------------------------------*/
/*** META ((export screen-dimensions) (arity -1)) */
function hop_screen_dimensions( unit ) {
   if( !unit ) unit = "cm";

   var d = document.createElement( "div" );
   var h = document.getElementsByTagName( "body" )[ 0 ];

   node_style_set( d, "visibility", "hidden" );
   node_style_set( d, "border", "0" );
   d.innerHTML = ".";

   h.appendChild( d );
   
   node_style_set( d, "width", "1" + unit );
   node_style_set( d, "height", "1" + unit );

   var res =
      new sc_Pair( Math.round( hop_config.screen_width / d.offsetWidth ),
		   Math.round( hop_config.screen_height / d.offsetHeight ) );

   h.removeChild( d );

   return res;
}
   
/*---------------------------------------------------------------------*/
/*    hop_iframe_scroll_height ...                                     */
/*---------------------------------------------------------------------*/
/*** META ((export iframe-scroll-height) (arity #t)) */
function hop_iframe_scroll_height( e ) {
   if( "contentDocument" in e ) {
      return e.contentDocument.body.scrollHeight;
   } else {
      if( "document" in e ) {
	 return e.document.body.scrollHeight;
      } else {
	 return iframe.height;
      }
   }
}

/*---------------------------------------------------------------------*/
/*    hop_iframe_scroll_width ...                                      */
/*---------------------------------------------------------------------*/
/*** META ((export iframe-scroll-width) (arity #t)) */
function hop_iframe_scroll_width( e ) {
   if( "contentDocument" in e ) {
      return e.contentDocument.body.scrollWidth;
   } else {
      if( "document" in e ) {
	 return e.document.body.scrollWidth;
      } else {
	 return iframe.width;
      }
   }
}

/*---------------------------------------------------------------------*/
/*    hop_get_selection                                                */
/*---------------------------------------------------------------------*/
/*** META ((export get-selection) (arity 0)) */
var hop_get_selection;

if( window.getSelection ) {
   hop_get_selection = function hop_get_selection() {
      return window.getSelection().toString();
   }
} else {
   if( document.getSelection ) {
      hop_get_selection = function hop_get_selection() {
	 return document.getSelection().toString();
      }
   } else {
      hop_get_selection = function hop_get_selection() {
	 if( document.selection ) {
	    return document.selection.createRange().text;
	 } else {
	    return "";
	 }
      }
   }
}

