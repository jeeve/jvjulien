/*=====================================================================*/
/*    serrano/prgm/project/hop/1.9.x/share/base64.js                   */
/*    -------------------------------------------------------------    */
/*    Author      :  Tyler Akins                                       */
/*    Creation    :  Thu Sep 21 15:34:59 2006                          */
/*    Last change :  Mon Dec  3 12:32:10 2007 (serrano)                */
/*    Copyright   :  2006-07 Manuel Serrano                            */
/*    -------------------------------------------------------------    */
/*    Simple base64 encoder/decoder                                    */
/*    -------------------------------------------------------------    */
/*    This code was written by Tyler Akins and has been placed in the  */
/*    public domain.  It would be nice if you left this header intact. */
/*    Base64 code from Tyler Akins -- http://rumkin.com                */
/*=====================================================================*/

var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

/*---------------------------------------------------------------------*/
/*    base64_encode ...                                                */
/*---------------------------------------------------------------------*/
/*** META ((export #t) (arity #t)) */
function base64_encode( input ) {
   var output = "";
   var chr1, chr2, chr3;
   var enc1, enc2, enc3, enc4;
   var i = 0;

   do {
      chr1 = input.charCodeAt( i++ );
      chr2 = input.charCodeAt( i++ );
      chr3 = input.charCodeAt( i++ );

      enc1 = chr1 >> 2;
      enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
      enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
      enc4 = chr3 & 63;

      if( isNaN( chr2 ) ) {
         enc3 = enc4 = 64;
      } else if( isNaN( chr3 ) ) {
         enc4 = 64;
      }

      output = output + keyStr.charAt( enc1 ) + keyStr.charAt( enc2 ) + 
         keyStr.charAt( enc3 ) + keyStr.charAt( enc4 );
   } while( i < input.length );
   
   return output;
}

/*---------------------------------------------------------------------*/
/*    function                                                         */
/*    utf8_decode ...                                                  */
/*---------------------------------------------------------------------*/
function utf8_decode( input ) {
   var string = "";
   var i = 0;
   var c = c1 = c2 = 0;

   while ( i < input.length ) {
      c = input.charCodeAt(i);

      if( c < 128 ) {
	 string += String.fromCharCode( c );
	 i++;
      }
      else if( (c > 191) && (c < 224) ) {
	 c2 = input.charCodeAt( i + 1 );
	 string += String.fromCharCode( ((c & 31) << 6) | (c2 & 63) );
	 i += 2;
      }
      else {
	 c2 = input.charCodeAt( i + 1 );
	 c3 = input.charCodeAt( i + 2 );
	 string += String.fromCharCode( ((c & 15) << 12) |
					((c2 & 63) << 6) |
					(c3 & 63) );
	 i += 3;
      }

   }

   return string;
}

/*---------------------------------------------------------------------*/
/*    function                                                         */
/*    base64_decode ...                                                */
/*---------------------------------------------------------------------*/
/*** META ((export #t) (arity #t)) */
function base64_decode( input ) {
   var output = "";
   var chr1, chr2, chr3;
   var enc1, enc2, enc3, enc4;
   var i = 0;

   // remove all characters that are not A-Z, a-z, 0-9, +, /, or =
   input = input.replace( /[^A-Za-z0-9\+\/\=]/g, "" );

   do {
      enc1 = keyStr.indexOf( input.charAt( i++ ) );
      enc2 = keyStr.indexOf( input.charAt( i++ ) );
      enc3 = keyStr.indexOf( input.charAt( i++ ) );
      enc4 = keyStr.indexOf( input.charAt( i++ ) );

      chr1 = (enc1 << 2) | (enc2 >> 4);
      chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
      chr3 = ((enc3 & 3) << 6) | enc4;

      output = output + String.fromCharCode( chr1 );

      if( enc3 != 64 ) {
         output = output + String.fromCharCode( chr2 );
      }
      if( enc4 != 64 ) {
         output = output + String.fromCharCode( chr3 );
      }
   } while( i < input.length );

   return utf8_decode( output );
}

